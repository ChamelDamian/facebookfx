package facebook;

import javafx.scene.control.Alert;

public class _showAlert {

    public void alertShow(Alert.AlertType alert, String title, String header, String msg){
        Alert dialog = new Alert(alert);
        dialog.setTitle(title);
        dialog.setHeaderText(header);
        dialog.setContentText(msg);
        dialog.showAndWait();
    }
}

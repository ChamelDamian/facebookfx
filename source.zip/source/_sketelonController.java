package facebook;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

public class _sketelonController implements Initializable {

    @FXML public AnchorPane anchor;
    @FXML public AnchorPane topBar;
    @FXML public TextField searchbar;
    @FXML public VBox vbox;
    @FXML public TabPane tabPane;

    _showAlert alert = new _showAlert();
    
    @FXML
    public void resize(){
        Stage stage = (Stage)anchor.getScene().getWindow();
        if(stage.isMaximized())
            stage.setMaximized(false);
        else
            stage.setMaximized(true);
    }
    @FXML
    public void close(){
        System.exit(0);
    }
    @FXML
    public void minimize(){
        Stage stage = (Stage)anchor.getScene().getWindow();
        stage.setIconified(true);
    }
    @FXML
    public void about(){
        alert.alertShow(AlertType.INFORMATION, "About", "Facebook Graph Api", "written by DAMIAN CHAMEL\n"
                + "owner of LEMAHC INDUSTRIES\nreleased ON AUG 18 2017\ncontact 9oaksys@gmail.com"
                + "\nfacebook Zigma Residence");
    }

    @FXML
    public void goAhead(){
        String path = "accessToken.txt";
        if(searchbar.getText().contains("https://")){
            try(BufferedWriter bw = new BufferedWriter(new FileWriter(new File(path)))){
                bw.write(searchbar.getText());
                bw.close();
                searchbar.clear();
                addTab();
            } catch (IOException ex) {
                alert.alertShow(AlertType.ERROR, "Error", "File writing error", ex.getMessage());
            }
        }else{
            alert.alertShow(AlertType.ERROR, "Error", "Access token failed", "You must enter the access token");
        }
    }

    public void addTab(){
        try{
            URL uri = getClass().getResource("Thetab.fxml");
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(uri);
            loader.setBuilderFactory(new JavaFXBuilderFactory());
            Node node = loader.load(uri.openStream());
            Tab tab = new Tab(new _facebook().getUserName(), node);
            tabPane.getTabs().add(tab);
            tab.setClosable(true);
        }catch(IOException ex){
            alert.alertShow(AlertType.ERROR, "Error", "Something went wrong", ex.getMessage());
        }
    }

    double x, y = 0.0;
    public void initMove(){
        topBar.setOnMousePressed((MouseEvent event) -> {
            x = event.getSceneX();
            y = event.getSceneY();
        });
        topBar.setOnMouseDragged((MouseEvent event) -> {
            Stage stage = (Stage)anchor.getScene().getWindow();
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenY() - y);
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle rb){
        addTab();
        initMove();
    }
}

package facebook;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;

public class _thatabController implements Initializable {

    @FXML public AnchorPane anchor;
    @FXML public ImageView imageViewer;
    @FXML public ListView listView;
    @FXML public Label userName, userEmail, userLocation;

    _facebook fb = new _facebook();
    _showAlert alert = new _showAlert();
    String rawusr = fb.getUserName();
    String rawmil = fb.getUserEmail();
    String rawlocation = fb.getUserLocation();
    String rawlocid = fb.getUserLocId();
    String rawimg = fb.getUserPicture();
    String rawdevices = fb.getUserDevice();
    String rawgender = fb.getUserGender();
    String rawbirth = fb.getUserBday();
    String rawid = fb.getUserId();
    String rawabout = fb.getUserAbout();
    String rawwork = fb.getUserWork();
    String rawschool = fb.getUserEducation();
    String rawagerange = fb.getUserAgeRange();
    String rawhometown = fb.getUserHomeTown();
    String rawworkloc = fb.getUserWorkLoc();
    String rawworkdes = fb.getUserWorkDes();
    String rawfriends = fb.getUserFriendList();
    String rawacctoken = fb.getUserAccessToken();
    
    final Clipboard clipb = Clipboard.getSystemClipboard();
    final ClipboardContent content = new ClipboardContent();
    ContextMenu menu = new ContextMenu();
    MenuItem item1 = new MenuItem("Copy");
    MenuItem item2 = new MenuItem("Delete");
    MenuItem item3 = new MenuItem("Write into text file");
    
    public void rightClicked(){
        item1.setOnAction(e -> {
            int c;
            String i;
            c = listView.getSelectionModel().getSelectedIndex();
            switch(c){
                case 0: i = rawid; break;
                case 1: i = rawusr; break;
                case 2: i = rawbirth; break;
                case 3: i = rawagerange; break;
                case 4: i = rawgender; break;
                case 5: i = rawmil; break;
                case 6: i = rawdevices; break;
                case 7: i = rawlocation + "(" + rawlocid + ")"; break;
                case 8: i = rawabout; break;
                case 9: i = rawhometown; break;
                case 10:i = rawschool; break;
                case 11:i = rawwork; break;
                case 12:i = rawworkloc; break;
                case 13:i = rawworkdes; break;
                case 14:i = rawfriends; break;
                case 15:i = rawacctoken; break;
                default:i = "";
            }
            content.putString(i);
            clipb.setContent(content);
        });
        item2.setOnAction(e -> {
            int c;
            c = listView.getSelectionModel().getSelectedIndex();
            listView.getItems().remove(c);
        });
        item3.setOnAction(e -> {
            try(BufferedWriter bw = new BufferedWriter(new FileWriter(new File("facebook.txt")));){
                bw.write(rawid); bw.newLine();
                bw.write(rawusr); bw.newLine();
                bw.write(rawbirth); bw.newLine();
                bw.write(rawagerange); bw.newLine();
                bw.write(rawgender); bw.newLine();
                bw.write(rawmil); bw.newLine();
                bw.write(rawdevices); bw.newLine();
                bw.write(rawlocation + "(" + rawlocid + ")"); bw.newLine();
                bw.write(rawabout); bw.newLine();
                bw.write(rawhometown); bw.newLine();
                bw.write(rawschool); bw.newLine();
                bw.write(rawwork); bw.newLine();
                bw.write(rawworkloc); bw.newLine();
                bw.write(rawworkdes); bw.newLine();
                bw.write(rawfriends); bw.newLine();
                bw.write(rawacctoken);
                bw.close();
            }catch(IOException ex){
                alert.alertShow(AlertType.ERROR, "Error", "File writing error", ex.getMessage());
            }
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle rb){
        menu.getItems().addAll(item1, item2, item3);
        menu.setAutoHide(true);
        listView.setOnMouseClicked((MouseEvent event) -> {
            if(event.isPopupTrigger()){
                rightClicked();
                menu.show(listView, event.getScreenX(), event.getScreenY());
            }else{
                menu.hide();
            }
        });
        try{
            userName.setText(rawusr);
            userEmail.setText(rawmil);
            userLocation.setText(rawlocation);
            Image image = new Image(new URL(rawimg).toURI().toString());
            imageViewer.setImage(image);
            listView.getItems().add(0, "id: " + rawid);
            listView.getItems().add(1, "name: " + rawusr);
            listView.getItems().add(2, "birthday: " + rawbirth);
            listView.getItems().add(3, "age_range: " + rawagerange);
            listView.getItems().add(4, "gender: " + rawgender);
            listView.getItems().add(5, "email: " + rawmil);
            listView.getItems().add(6, "devices: " + rawdevices);
            listView.getItems().add(7, "location: " + rawlocation + "(" + rawlocid + ")");
            listView.getItems().add(8, "about: " + rawabout);
            listView.getItems().add(9, "home_town: " + rawhometown);
            listView.getItems().add(10,"school: " + rawschool);
            listView.getItems().add(11,"work: " + rawwork);
            listView.getItems().add(12,"work_location: " + rawworkloc);
            listView.getItems().add(13,"work_description: " + rawworkdes);
            listView.getItems().add(14,"friend_list: " + rawfriends);
            listView.getItems().add(15,"access_token: " + rawacctoken);
        } catch (URISyntaxException | MalformedURLException ex) {
            alert.alertShow(AlertType.ERROR, "Error", "Image loading error", ex.getMessage());
        }
    }
    
}

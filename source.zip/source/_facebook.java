package facebook;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import javafx.scene.control.Alert.AlertType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class _facebook {
    public String userName = "";
    public String userId = "";
    public String userBday = "";
    public String userEmail = "";
    public String userGender = "";
    public String userAbout = "";
    public String userAgeRange = "";
    public String userSchool = "";
    public String userLocation = "";
    public String userLocId = "";
    public String userWork = "";
    public String userWorkLoc = "";
    public String userWorkDes = "";
    public String userDevice = "";
    public String userPicture = "";
    public String userHomeTown = "";
    public String userFriendList = "";
    public String userAccessToken = "";
    
    _showAlert alert = new _showAlert();
    public _facebook(){
        try{
            BufferedReader bf = new BufferedReader(new FileReader("accessToken.txt"));
            String uri = bf.readLine();
            userAccessToken = uri;
            if(uri.equals("")) System.out.println("AccessToken empty");
            else System.out.println("AccessToken working");
            JSONObject js = runUri(uri);
            this.userName = js.getString("name");
            this.userAbout = js.getString("about");
            this.userId = js.getString("id");
            this.userBday = js.getString("birthday");
            this.userGender = js.getString("gender");
            this.userEmail = js.getString("email");
            this.userPicture = "https://graph.facebook.com/" + userId + "/picture?type=large";
            JSONObject location = js.getJSONObject("location");
            this.userLocId = location.getString("id");
            this.userLocation = location.getString("name");
            JSONArray devices = js.getJSONArray("devices");
            for(int i = devices.length()-1; i >= 0; i--){
                JSONObject device = devices.getJSONObject(i);
                this.userDevice += device.getString("os") + ((devices.length() > 1) ? ", " : "" );
            }
            JSONObject hometown = js.getJSONObject("hometown");
            this.userHomeTown = hometown.getString("name");
            JSONObject age_range = js.getJSONObject("age_range");
            this.userAgeRange = String.valueOf(age_range.getInt("min")) + "-" + String.valueOf(age_range.getInt("max"));
            JSONArray education = js.getJSONArray("education");
            for(int i = education.length()-1; i >= 0; i--){
                JSONObject ed01 = education.getJSONObject(i);
                JSONObject school = ed01.getJSONObject("school");
                this.userSchool += school.getString("name") + "(" + ed01.getString("type")
                        + ")" + ((education.length() > 1) ? ", " : "");
            }
            JSONArray work = js.getJSONArray("work");
            for(int i  = work.length()-1; i >= 0; i--){
                JSONObject ob01 = work.getJSONObject(i);
                JSONObject wlocation = ob01.getJSONObject("location");
                JSONObject position = ob01.getJSONObject("position");
                JSONObject employer = ob01.optJSONObject("employer");
                this.userWork = employer.getString("name") + "(" + position.getString("name") + ")";
                this.userWorkLoc = wlocation.getString("name");
                this.userWorkDes = ob01.getString("description");
            }
            JSONObject friendlist = js.getJSONObject("friendlists");
            JSONArray data = friendlist.getJSONArray("data");
            for(int i = data.length()-1; i >= 0; i--){
                JSONObject ob01 = data.getJSONObject(i);
                this.userFriendList += ob01.getString("name") + ((data.length() > 1) ? ", ":"");
            }
        }catch(IOException ex){
            alert.alertShow(AlertType.ERROR, "Error", "Access Token not found", ex.getMessage());
        }catch(JSONException exx){
            alert.alertShow(AlertType.ERROR, "Error", "JSON not found", exx.getMessage());
        }
    }
    public String getUserName(){ return userName; }
    public String getUserId(){ return userId; }
    public String getUserBday(){ return userBday; }
    public String getUserEmail(){ return userEmail; }
    public String getUserGender(){ return userGender; }
    public String getUserAbout(){ return userAbout; }
    public String getUserAgeRange(){ return userAgeRange; }
    public String getUserEducation(){ return userSchool; }
    public String getUserLocation(){ return userLocation; }
    public String getUserWork(){ return userWork; }
    public String getUserDevice(){ return userDevice; }
    public String getUserPicture(){ return userPicture; }
    public String getUserHomeTown(){ return userHomeTown; }
    public String getUserLocId(){ return userLocId; }
    public String getUserWorkLoc(){ return userWorkLoc; }
    public String getUserWorkDes(){ return userWorkDes; }
    public String getUserFriendList(){ return userFriendList; }
    public String getUserAccessToken(){ return userAccessToken; }
    
    public String readAll(Reader r) throws IOException {
        StringBuilder sb = new StringBuilder();
        int i;
        while((i = r.read()) != -1){
            sb.append((char)i);
        }
        return sb.toString();
    }
    public final JSONObject runUri(String n) throws JSONException{
        try{
            URL uri = new URL(n);
            InputStream is = uri.openStream();
            BufferedReader bf = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF8")));
            String s = bf.readLine();
            JSONObject jobj = new JSONObject(s);
            return jobj;
        }catch(IOException ex){
            alert.alertShow(AlertType.ERROR, "Error", "Network failed", ex.getMessage());
            return null;
        }catch(JSONException ex){
            alert.alertShow(AlertType.ERROR, "Error", "Data fetching error", ex.getMessage());
            return null;
        }
    }
}
